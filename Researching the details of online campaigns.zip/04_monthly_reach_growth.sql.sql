WITH all_ads AS (
    SELECT
        fbd.ad_date,
        'Facebook' AS platform,
        fbd.campaign_id,
        fc.campaign_name,
        fbd.adset_id,
        fa.adset_name,
        fbd.spend,
        fbd.impressions,
        fbd.reach,
        fbd.clicks,
        fbd.value
    FROM public.facebook_ads_basic_daily fbd
    LEFT JOIN public.facebook_adset fa ON fbd.adset_id = fa.adset_id
    LEFT JOIN public.facebook_campaign fc ON fbd.campaign_id = fc.campaign_id

    UNION ALL

    SELECT
        gad.ad_date,
        'Google' AS platform,
        NULL AS campaign_id,
        gad.campaign_name,
        NULL AS adset_id,
        NULL AS adset_name,
        gad.spend,
        gad.impressions,
        gad.reach,
        gad.clicks,
        gad.value
    FROM public.google_ads_basic_daily gad
),

facebook_only AS (
    SELECT *
    FROM all_ads
    WHERE platform = 'Facebook' AND reach IS NOT NULL AND campaign_name IS NOT NULL
),

monthly_reach_camp AS (
    SELECT 
        TO_CHAR(ad_date, 'YYYY-MM') AS ad_month,
        campaign_name,
        COALESCE(SUM(reach), 0) AS monthly_reach
    FROM all_ads_data
    WHERE campaign_name IS NOT NULL AND reach IS NOT NULL
    GROUP BY ad_month, campaign_name
),

reach_growth AS (
    SELECT 
        ad_month,
        campaign_name,
        monthly_reach,
        monthly_reach - COALESCE(
            LAG(monthly_reach) OVER (PARTITION BY campaign_name ORDER BY ad_month),
            0
        ) AS monthly_growth
    FROM monthly_reach_camp
)

SELECT *
FROM reach_growth
ORDER BY monthly_growth DESC
LIMIT 1;




