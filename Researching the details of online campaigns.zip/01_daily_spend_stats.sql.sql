WITH all_ads AS (
    SELECT
        fbd.ad_date,
        'Facebook' AS platform,
        fbd.campaign_id,
        fc.campaign_name,
        fbd.adset_id,
        fa.adset_name,
        fbd.spend,
        fbd.impressions,
        fbd.reach,
        fbd.clicks,
        fbd.value
    FROM public.facebook_ads_basic_daily fbd
    LEFT JOIN public.facebook_adset fa ON fbd.adset_id = fa.adset_id
    LEFT JOIN public.facebook_campaign fc ON fbd.campaign_id = fc.campaign_id

    UNION ALL

    SELECT
        gad.ad_date,
        'Google' AS platform,
        NULL AS campaign_id,
        gad.campaign_name,
        NULL AS adset_id,
        NULL AS adset_name,
        gad.spend,
        gad.impressions,
        gad.reach,
        gad.clicks,
        gad.value
    FROM public.google_ads_basic_daily gad
)
SELECT
    platform,
    ad_date,
    ROUND(AVG(spend)::numeric, 2) AS avg_spend,
    ROUND(MIN(spend)::numeric, 2) AS min_spend,
    ROUND(MAX(spend)::numeric, 2) AS max_spend
FROM all_ads
GROUP BY platform, ad_date
ORDER BY platform, ad_date;
